var Serie = /** @class */ (function () {
    function Serie(id, name, channel, season) {
        this.id = id;
        this.name = name;
        this.channel = channel;
        this.season = season;
    }
    return Serie;
}());
export { Serie };
